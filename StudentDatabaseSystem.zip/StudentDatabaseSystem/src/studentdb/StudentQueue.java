package studentdb;
public class StudentQueue {
    private Node front, rear;
    
    class Node {
        String rollNo, name, fatherName, phone, email, address, department, gender, dob;
        double cgpa;
        Node next;
        
        Node(String rollNo, String name, String fatherName, String phone, String email, 
             String address, String department, String gender, String dob, double cgpa) {
            this.rollNo = rollNo;
            this.name = name;
            this.fatherName = fatherName;
            this.phone = phone;
            this.email = email;
            this.address = address;
            this.department = department;
            this.gender = gender;
            this.dob = dob;
            this.cgpa = cgpa;
            this.next = null;
        }
    }
    
    public StudentQueue() {
        this.front = this.rear = null;
    }
    
    public void enqueue(String rollNo, String name, String fatherName, String phone, 
                       String email, String address, String department, String gender, 
                       String dob, double cgpa) {
        Node newNode = new Node(rollNo, name, fatherName, phone, email, address, 
                               department, gender, dob, cgpa);
        
        if (rear == null) {
            front = rear = newNode;
        } else {
            rear.next = newNode;
            rear = newNode;
        }
        System.out.println("Student added: " + name);
    }
    
    public Node searchByRoll(String rollNo) {
        Node current = front;
        while (current != null) {
            if (current.rollNo.equals(rollNo)) {
                return current;
            }
            current = current.next;
        }
        return null;
    }
    
    // ✅ ADD THIS updateStudent METHOD
    public boolean updateStudent(String rollNo, String newName, String newDept, double newCgpa) {
        Node student = searchByRoll(rollNo);
        if (student != null) {
            student.name = newName;
            student.department = newDept;
            student.cgpa = newCgpa;
            return true;
        }
        return false;
    }
    
    public boolean removeByRoll(String rollNo) {
        if (front == null) return false;
        
        if (front.rollNo.equals(rollNo)) {
            front = front.next;
            if (front == null) rear = null;
            return true;
        }
        
        Node current = front;
        while (current.next != null) {
            if (current.next.rollNo.equals(rollNo)) {
                current.next = current.next.next;
                if (current.next == null) rear = current;
                return true;
            }
            current = current.next;
        }
        return false;
    }
    
    public String[][] getAllStudents() {
        if (front == null) {
            return new String[0][10];
        }
        
        int count = 0;
        Node current = front;
        while (current != null) {
            count++;
            current = current.next;
        }
        
        String[][] studentData = new String[count][10];
        current = front;
        int index = 0;
        
        while (current != null) {
            studentData[index][0] = current.rollNo;
            studentData[index][1] = current.name;
            studentData[index][2] = current.fatherName;
            studentData[index][3] = current.department;
            studentData[index][4] = String.valueOf(current.cgpa);
            studentData[index][5] = current.phone;
            studentData[index][6] = current.email;
            studentData[index][7] = current.address;
            studentData[index][8] = current.dob;
            studentData[index][9] = current.gender;
            current = current.next;
            index++;
        }
        
        return studentData;
    }
}