package studentdb;

public class MainQueue {
    public static StudentQueue queue = new StudentQueue();
}